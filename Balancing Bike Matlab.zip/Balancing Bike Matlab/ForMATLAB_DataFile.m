% Simscape(TM) Multibody(TM) version: 6.1

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(4).translation = [0.0 0.0 0.0];
smiData.RigidTransform(4).angle = 0.0;
smiData.RigidTransform(4).axis = [0.0 0.0 0.0];
smiData.RigidTransform(4).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0 10.000000000000009 0];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[Fly_wheel-1:-:Aniruddha Ki Cycle-MarkII-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [-150.35277595344382 165.04422515807181 318.14990040302951];  % mm
smiData.RigidTransform(2).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(2).axis = [-0.57735026918962618 -0.57735026918962595 0.57735026918962518];
smiData.RigidTransform(2).ID = 'F[Fly_wheel-1:-:Aniruddha Ki Cycle-MarkII-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [134.56321854619651 66.300682882673186 1001.7237121983817];  % mm
smiData.RigidTransform(3).angle = 0;  % rad
smiData.RigidTransform(3).axis = [0 0 0];
smiData.RigidTransform(3).ID = 'RootGround[BASEplate-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [312.07056980558423 93.182201404660461 683.57381179535219];  % mm
smiData.RigidTransform(4).angle = 0.038486270822985266;  % rad
smiData.RigidTransform(4).axis = [0 0 -1];
smiData.RigidTransform(4).ID = 'SixDofRigidTransform[Aniruddha Ki Cycle-MarkII-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(3).mass = 0.0;
smiData.Solid(3).CoM = [0.0 0.0 0.0];
smiData.Solid(3).MoI = [0.0 0.0 0.0];
smiData.Solid(3).PoI = [0.0 0.0 0.0];
smiData.Solid(3).color = [0.0 0.0 0.0];
smiData.Solid(3).opacity = 0.0;
smiData.Solid(3).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.62470345616595813;  % kg
smiData.Solid(1).CoM = [-117.96433897258667 71.60352411531359 318.06096504246045];  % mm
smiData.Solid(1).MoI = [1421.7385559130619 5849.578920684864 6965.8814981853575];  % kg*mm^2
smiData.Solid(1).PoI = [-1.348541582926148 10.832279023448578 364.7402544106655];  % kg*mm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'Aniruddha Ki Cycle-MarkII*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 3;  % kg
smiData.Solid(2).CoM = [0 5 0];  % mm
smiData.Solid(2).MoI = [22524.999999999996 272500.00000000006 250025.00000000006];  % kg*mm^2
smiData.Solid(2).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'BASEplate*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.1157930814622546;  % kg
smiData.Solid(3).CoM = [7.2509758663315446e-08 6.0843128353837868 0.011718545342647347];  % mm
smiData.Solid(3).MoI = [183.28331055065692 361.5645964381045 183.29711644263224];  % kg*mm^2
smiData.Solid(3).PoI = [-0.013455221538641675 5.1867263908207657e-08 -1.0681103467353181e-07];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'Fly_wheel*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(1).Rz.Pos = 0.0;
smiData.RevoluteJoint(1).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = 123.10901870420417;  % deg
smiData.RevoluteJoint(1).ID = '[Fly_wheel-1:-:Aniruddha Ki Cycle-MarkII-1]';

